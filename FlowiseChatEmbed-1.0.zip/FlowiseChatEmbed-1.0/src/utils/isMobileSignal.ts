import { createSignal } from 'solid-js';

export const [isMobile, setIsMobile] = createSignal<boolean>();
